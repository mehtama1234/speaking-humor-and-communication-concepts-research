# Wave-2 full-context candidate review

This focused reviewer pack contains exactly 19 provisional candidates: seven
Ali Siddiq, six Dry Bar Comedy, and six TED. The other 88 IDs in the combined
review queue are not shown and remain explicitly unreviewed in exports. The pack
includes all 56 cited transcript references, their 43 unique
full transcripts and 43 unique cue/timing files, plus direct links to
the source videos.

## Independence and task

Review independently of the people who assembled the transcript packets,
proposed these candidate patterns, and created the crosswalk. Do not view or
discuss another reviewer's decisions before returning yours. Use a pseudonymous
reviewer code. For each displayed candidate, inspect the original source video
and all cited full-transcript/cue context, not only the retrieved excerpts.
Choose supports, does not support, or indeterminate and record uncertainty,
identity concerns, and counterexamples. Do not infer recurrence, transfer, or
effectiveness.

## Browser and export

Unzip while preserving the folder structure, then open
`site/pattern-review-wave-2.html`. Review the 19 displayed items and export the
completed records. The exported denominator remains 107, with the other 88 IDs
explicitly listed as unreviewed. Return the JSON unchanged. From the project
repository, validate it with:

```text
python3 scripts/validate_source_pattern_review_export.py reviewer-wave-2.json
```

Expected targeted coverage is `19/107`, partial with missingness preserved,
and wave-2 coverage `19/19`. Preserve reviewer exports separately. Contextual
fit does not establish source identity across events, recurrence, delivery
meaning, learner transfer, listener outcomes, or effectiveness. No review
decisions are included in this pack.
